package com.sz.otgconnector;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.sz.otgconnector.USB_PERMISSION";
    private UsbManager usbManager;
    private TextView status;
    private LinearLayout deviceList;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (ACTION_USB_PERMISSION.equals(intent.getAction())) {
                UsbDevice device = getUsbDevice(intent);
                if (device != null) {
                    boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                    status.setText(granted
                        ? "USB permission granted. Device detected; this app does not yet record microphone audio."
                        : "USB permission denied. Unlock the phone and allow the USB permission prompt.");
                    refreshDevices();
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())
                    || UsbManager.ACTION_USB_DEVICE_DETACHED.equals(intent.getAction())) {
                refreshDevices();
            }
        }
    };

    @SuppressWarnings("deprecation")
    private UsbDevice getUsbDevice(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        }
        return intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(20));
        root.setBackgroundColor(0xFFF4F7FB);

        TextView title = new TextView(this);
        title.setText("OTG CONNECTOR");
        title.setTextSize(26);
        title.setTextColor(0xFF14233B);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("USB receiver detector for Android");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF52627A);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.bottomMargin = dp(20);
        root.addView(subtitle, subParams);

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextColor(0xFF17243A);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        status.setBackgroundColor(0xFFFFFFFF);
        root.addView(status, matchWrap());

        Button scan = new Button(this);
        scan.setText("SCAN USB / MIC RECEIVER");
        scan.setOnClickListener(v -> refreshDevices());
        LinearLayout.LayoutParams scanParams = matchWrap();
        scanParams.topMargin = dp(14);
        root.addView(scan, scanParams);

        TextView note = new TextView(this);
        note.setText("Important: this app checks whether Android detects a USB device and can request USB permission. It cannot turn on missing hardware/USB-host support, and USB detection does not guarantee the receiver works as an audio input.");
        note.setTextSize(13);
        note.setTextColor(0xFF52627A);
        note.setPadding(0, dp(14), 0, dp(14));
        root.addView(note, matchWrap());

        TextView heading = new TextView(this);
        heading.setText("Detected devices");
        heading.setTextSize(18);
        heading.setTextColor(0xFF14233B);
        heading.setTypeface(null, 1);
        root.addView(heading, matchWrap());

        deviceList = new LinearLayout(this);
        deviceList.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(deviceList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);

        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbReceiver, filter);
        }
        refreshDevices();
    }

    private void refreshDevices() {
        deviceList.removeAllViews();
        HashMap<String, UsbDevice> devices = usbManager.getDeviceList();
        if (devices.isEmpty()) {
            status.setText("No USB device detected. Connect the receiver directly or with a compatible USB-C OTG adapter, then tap Scan.");
            TextView empty = new TextView(this);
            empty.setText("No USB devices found.");
            empty.setTextSize(15);
            empty.setTextColor(0xFF52627A);
            empty.setPadding(0, dp(10), 0, dp(10));
            deviceList.addView(empty);
            return;
        }

        status.setText("Android detected " + devices.size() + " USB device(s). Tap Request permission for a device.");
        for (UsbDevice device : devices.values()) {
            TextView item = new TextView(this);
            item.setText("Device: " + device.getDeviceName()
                    + "\nVendor ID: " + device.getVendorId()
                    + "   Product ID: " + device.getProductId()
                    + "\nUSB class: " + device.getDeviceClass());
            item.setTextSize(14);
            item.setTextColor(0xFF17243A);
            item.setPadding(dp(12), dp(12), dp(12), dp(12));
            item.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams itemParams = matchWrap();
            itemParams.bottomMargin = dp(8);
            deviceList.addView(item, itemParams);

            Button permission = new Button(this);
            permission.setText("REQUEST USB PERMISSION");
            permission.setOnClickListener(v -> requestUsbPermission(device));
            deviceList.addView(permission, matchWrap());
        }
    }

    private void requestUsbPermission(UsbDevice device) {
        Intent intent = new Intent(ACTION_USB_PERMISSION);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, flags);
        usbManager.requestPermission(device, pendingIntent);
        status.setText("USB permission requested. Check for Android's permission pop-up.");
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(usbReceiver); } catch (Exception ignored) {}
    }
}
