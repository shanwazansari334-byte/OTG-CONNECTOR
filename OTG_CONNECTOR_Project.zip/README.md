# OTG CONNECTOR

A minimal Android project that lists USB devices Android exposes and requests USB permission.

## Build an APK using only your phone and GitHub

1. Download and extract this ZIP on your phone.
2. Open GitHub in your browser and create a new repository named `OTG-CONNECTOR`.
3. Upload the extracted **files and folders inside** this project to the repository root (not the ZIP itself). Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab. If GitHub asks, enable Actions.
5. Choose **Build OTG CONNECTOR APK** → **Run workflow**. If that option is not shown, make a small commit/push to the `main` branch to trigger the workflow.
6. Wait for the run to finish with a green check.
7. Open that successful run, scroll to **Artifacts**, and download `OTG-CONNECTOR-debug-apk`.
8. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installing unknown apps for the browser/file manager you used.

## Important limitations

- This is a starter prototype, not a complete microphone recorder or audio-routing app.
- It detects USB devices Android exposes and demonstrates the USB permission request.
- It cannot enable USB host support if the phone/adapter/receiver combination does not support it.
- USB permission does not automatically make a USB receiver work as an audio input. The receiver must be compatible with Android USB audio.
- The project is unsigned debug output, suitable for testing on your own phone. Do not share it as a trusted public release without review and a proper release-signing setup.
